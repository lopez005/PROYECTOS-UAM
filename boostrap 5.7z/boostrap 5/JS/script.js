console.log("Hello World");
var a = 1;
var b = 2;
var R = a+b;
console.log("Resultado suma:"+ R)

console.log("Hello World");
var c= 2;
var n = 2;
var J = c*n;
console.log("Resultado multiplicacion:"+ J)

Math. sqrt(1244)

/*console.log("Numeros primos del 1 al 500.000")
function esPrimos (numeros) {

    for (let i = 2, reaiz=Math.sqrt(numeros);<=raiz i++)
    if(numero % i === 0) return false;
    return numero > 1;
}
for (let x=0;x<=500.000;x++) {
    if (esPrimo(x))
        consola.log("el numero" + x +"es primo")

}*/ 